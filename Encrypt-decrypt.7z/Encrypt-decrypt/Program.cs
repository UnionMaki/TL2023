﻿namespace Task2
{
    internal class Program
    {
        static void Main()
        {
            string inputLine = Console.ReadLine();
            Console.WriteLine("Шифровка:");
            EnCrypt(inputLine);
            Console.WriteLine("Расшифровка:");
            DeCrypt(inputLine);
        }
        static void EnCrypt(string inputline)
        {
            string Al = "АБВГДЕЁЖЗИКЛМНОПРСТУФХЦЧШЩЪЬЫЭЮЯабвгдеёжзиклмнопрстуфхцчшщъьыэюя";
            string _inputLine = inputline;
            foreach (char ch in _inputLine)
            {
                int i = 0;
                while (ch != Al[i])
                {
                    i++;
                }
                if (i == 0)
                    Console.Write("Ю");
                else
                    if (i == 1)
                        Console.Write("Я");
                    else
                        if (i == 32)
                            Console.Write("ю");
                        else
                            if (i == 33)
                                Console.Write("я");
                            else
                Console.Write(Al[i - 2]);
            }
            Console.WriteLine();

        }
        static void DeCrypt(string inputline)
        {
            string Al = "АБВГДЕЁЖЗИКЛМНОПРСТУФХЦЧШЩЪЬЫЭЮЯабвгдеёжзиклмнопрстуфхцчшщъьыэюя";
            string _inputLine = inputline;
            foreach (char ch in _inputLine)
            {
                int i = 0;
                while (ch != Al[i])
                {
                    i++;
                }
                if (i == 31)
                    Console.Write("А");
                else
                    if (i == 32)
                        Console.Write("Б");
                    else
                        if (i == 62)
                            Console.Write("а");
                        else
                            if (i == 63)
                                 Console.Write("б");
                            else
                                Console.Write(Al[i + 2]);
            }

        }
    }
}

           
